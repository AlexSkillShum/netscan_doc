import os
import argparse
import requests
import json

def do_ping_sweep(ip, num_of_host):                             # функция скана хостов, на вход два аргумента
    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    response = os.popen(f'ping -n 2 {scanned_ip}')
    res = response.readlines()
    print(f"[#] Result of scanning: {scanned_ip} [#]\n{res[2]}", end='\n') # вывод результата
    for line in res:
        print(line.encode('cp1251').decode('cp866'))  # для запуска в Windows - производит преобразование
def sent_http_request(target, method, headers=None, payload=None):  # функция http-прокси-сервера
                                                                    # (отправка http-запросов и вывод ответов
     headers_dict = dict()
     if headers:
         for header in headers:                                     # преобразование введенных данных в список
             header_name = header.split(':')[0]                     # записывается название заголовка (до первого двоеточия)
             header_value = header.split(':')[1:]                   # записывается значение заголовка (
             headers_dict[header_name] = ':'.join(header_value)     # пары значений записываются в словарь headers_dict
     # выбор методов
     if method == "GET":
         response = requests.get(target, headers=headers_dict)      # отправка запроса get и сохранение ответа в response
     elif method == "POST":
         response = requests.post(target, headers=headers_dict, data=payload) # отправка запроса post и сохранение ответа в response
     # вывод полученного http-ответа
     print(
         f"[#] Response status code: {response.status_code}\n"          
         f"[#] Response headers: {json.dumps(dict(response.headers), indent=30, sort_keys=True)}\n" # преобразование в формат json
         f"[#] Response content:\n {response.text}"
    )

parser = argparse.ArgumentParser(description='Network scanner')
parser.add_argument('-ta', '--task', choices=['scan', 'sendhttp'], help='Network scan or send HTTP request')
parser.add_argument('-i', '--ip', type=str, help='IP address')
parser.add_argument('-n', '--num_of_hosts', type=int, help='Number of hosts')
parser.add_argument('-t', '--target', type=str, help='URL')
parser.add_argument('-m', '--method', type=str, help='Method')
parser.add_argument('-hd', '--headers', type=str, nargs='*', help='Headers')
args = parser.parse_args()

if args.task == 'scan':
  for host_num in range(args.num_of_hosts):
        do_ping_sweep(args.ip, host_num)
elif args.task == 'sendhttp':
       sent_http_request(args.target, args.method, args.headers)
